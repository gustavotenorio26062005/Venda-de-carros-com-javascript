function toggleDisplay(element, displayStyle) {
    element.style.display = displayStyle;
}

function updateLamborghiniContent(element) {
    element.innerHTML = 'A Lamborghini é sinônimo de potência, design inovador e exclusividade. Fundada em 1963 na Itália, a marca é conhecida por seus carros esportivos de alto desempenho, que combinam uma estética agressiva e futurista com uma engenharia de ponta. <br> Modelos como o Aventador e o Huracán tornaram-se ícones no mundo automotivo, atraindo admiradores e colecionadores. A Lamborghini não apenas produz carros rápidos, mas também verdadeiras obras de arte sobre rodas.<br><h2>Este carro é de 2018 Ele custa R$ 3.450.680,00 </h2>                    <form action=""> <button type="selection" id="botao1" onclick="opção1()">1x sem juros</button><button type="selection" id="botao2" onclick="opção2()">2x sem juros</button><button type="selection" id="botao3" onclick="opção3()">3x sem juros</button><button type="button" id="formulario">compre já</button></form>';
}
function opção1() {
    alert("Você deve pagar: R$3.450.680,00")
}
function opção2() {
    alert("Você deve pagar: R$1.725.340,00")
}
function opção3() {
    alert("Você deve pagar: R$1.150.226,70")
}
document.getElementById("toggleLamborghini").addEventListener("click", function() {
    let lamborghini = document.getElementById("Lamborghini");

    if (lamborghini.style.display === "none" || lamborghini.style.display === "") {
        toggleDisplay(lamborghini, "block");
        updateLamborghiniContent(lamborghini);
    } else {
        toggleDisplay(lamborghini, "none");
    }
});

document.getElementById("toggleAston").addEventListener("click", function() {
    let Aston = document.getElementById("Aston");
    if (Aston.style.display === "none" || Aston.style.display === "") {
        Aston.style.display = "block";
        Aston.innerHTML = "A Lamborghini é sinônimo de potência, design inovador e exclusividade. Fundada em 1963 na Itália, a marca é conhecida por seus carros esportivos de alto desempenho, que combinam uma estética agressiva e futurista com uma engenharia de ponta. Modelos como o Aventador e o Huracán tornaram-se ícones no mundo automotivo, atraindo admiradores e colecionadores. A Lamborghini não apenas produz carros rápidos, mas também verdadeiras obras de arte sobre rodas.";
    } else {
        Aston.style.display = "none";
    }
});


document.getElementById("toggleFerrari").addEventListener("click", function() {
    let Ferrari = document.getElementById("Ferrari");
    if (Ferrari.style.display === "none" || Ferrari.style.display === "") {
        Ferrari.style.display = "block";
        Ferrari.innerHTML = "A Lamborghini é sinônimo de potência, design inovador e exclusividade. Fundada em 1963 na Itália, a marca é conhecida por seus carros esportivos de alto desempenho, que combinam uma estética agressiva e futurista com uma engenharia de ponta. Modelos como o Aventador e o Huracán tornaram-se ícones no mundo automotivo, atraindo admiradores e colecionadores. A Lamborghini não apenas produz carros rápidos, mas também verdadeiras obras de arte sobre rodas.";
    } else {
        Ferrari.style.display = "none";
    }
});


document.getElementById("toggleJaguar").addEventListener("click", function() {
    let Jaguar = document.getElementById("Jaguar");
    if (Jaguar.style.display === "none" || Jaguar.style.display === "") {
        Jaguar.style.display = "block";
        Jaguar.innerHTML = "A Jaguar é sinônimo de potência, design inovador e exclusividade. Fundada em 1963 na Itália, a marca é conhecida por seus carros esportivos de alto desempenho, que combinam uma estética agressiva e futurista com uma engenharia de ponta. Modelos como o Aventador e o Huracán tornaram-se ícones no mundo automotivo, atraindo admiradores e colecionadores. A Lamborghini não apenas produz carros rápidos, mas também verdadeiras obras de arte sobre rodas.";
    } else {
        Jaguar.style.display = "none";
    }
});


document.getElementById("toggleBugatti").addEventListener("click", function() {
    let Bugatti = document.getElementById("Bugatti");
    if (Bugatti.style.display === "none" || Bugatti.style.display === "") {
        Bugatti.style.display = "block";
        Bugatti.innerHTML = "A Lamborghini é sinônimo de potência, design inovador e exclusividade. Fundada em 1963 na Itália, a marca é conhecida por seus carros esportivos de alto desempenho, que combinam uma estética agressiva e futurista com uma engenharia de ponta. Modelos como o Aventador e o Huracán tornaram-se ícones no mundo automotivo, atraindo admiradores e colecionadores. A Lamborghini não apenas produz carros rápidos, mas também verdadeiras obras de arte sobre rodas.";
    } else {
        Bugatti.style.display = "none";
    }
});


document.getElementById("toggleRolls").addEventListener("click", function() {
    let Rolls = document.getElementById("Rolls");
    if (Rolls.style.display === "none" || Rolls.style.display === "") {
        Rolls.style.display = "block";
        Rolls.innerHTML = "A Lamborghini é sinônimo de potência, design inovador e exclusividade. Fundada em 1963 na Itália, a marca é conhecida por seus carros esportivos de alto desempenho, que combinam uma estética agressiva e futurista com uma engenharia de ponta. Modelos como o Aventador e o Huracán tornaram-se ícones no mundo automotivo, atraindo admiradores e colecionadores. A Lamborghini não apenas produz carros rápidos, mas também verdadeiras obras de arte sobre rodas.";
    } else {
        Rolls.style.display = "none";
    }
});


